import {useEffect,useRef} from 'react';
import {ArrowUpRight} from 'lucide-react';
import {NEW_PHOTOS} from './new-photos';

export function useScrollReveals(view:string){
 useEffect(()=>{
  const media=matchMedia('(prefers-reduced-motion: reduce)');
  const nodes=Array.from(document.querySelectorAll<HTMLElement>('.feeling-copy,.memory-heading,.memory,.section-top,.shooting-copy,.about-copy,.process-grid article,.values article,.review-card,.contact-banner h2'));
  const show=()=>nodes.forEach(n=>{n.classList.remove('reveal-ready');n.classList.add('is-revealed')});
  if(media.matches||!('IntersectionObserver' in window)){show();return}
  const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('is-revealed');observer.unobserve(e.target)}}),{threshold:.1,rootMargin:'0px 0px -25px 0px'});
  nodes.forEach((n,i)=>{n.classList.add('reveal-ready');n.style.setProperty('--reveal-delay',`${n.matches('.process-grid article,.memory')?(i%3)*90:0}ms`);observer.observe(n)});
  const onChange=()=>{if(media.matches){show();observer.disconnect()}};
  media.addEventListener('change',onChange);
  return()=>{observer.disconnect();media.removeEventListener('change',onChange)};
 },[view]);
}

export default function ScrollStories(){
 const ref=useRef<HTMLElement>(null);
 useEffect(()=>{
  const node=ref.current;if(!node)return;
  const media=matchMedia('(prefers-reduced-motion: reduce)');let frame=0;
  const update=()=>{frame=0;const r=node.getBoundingClientRect();const header=innerWidth<=760?82:105;const p=media.matches?1:Math.max(0,Math.min(1,(header-r.top)/Math.max(1,r.height-innerHeight+header)));
   node.style.setProperty('--story-p',String(p));node.style.setProperty('--story-inset',`${Math.max(0,31-p*58)}%`);node.style.setProperty('--story-y',`${Math.max(0,12-p*24)}%`);node.style.setProperty('--story-round',`${Math.max(0,160-p*340)}px`);node.style.setProperty('--story-side',String(Math.max(0,1-p*2.1)));node.style.setProperty('--story-text',String(Math.min(1,Math.max(0,(p-.43)*4))));
  };
  const schedule=()=>{if(!frame)frame=requestAnimationFrame(update)};update();addEventListener('scroll',schedule,{passive:true});addEventListener('resize',schedule);media.addEventListener('change',schedule);
  return()=>{cancelAnimationFrame(frame);removeEventListener('scroll',schedule);removeEventListener('resize',schedule);media.removeEventListener('change',schedule)};
 },[]);
 return <section ref={ref} className="scroll-stories" aria-label="Les histoires Golden Moment en images"><div className="stories-stage">
  <div className="stories-intro"><p className="eyebrow">CHAQUE HISTOIRE A SA LUMIÈRE</p><h2>Un regard.<br/><em>Tout un monde.</em></h2></div>
  <div className="stories-photo"><img src={NEW_PHOTOS['nouveau-couple-voile']} alt="Un couple de mariés réuni sous un voile de dentelle" loading="lazy"/><div className="stories-shade"/></div>
  <div className="story-side story-left" aria-hidden="true"><img src={NEW_PHOTOS['nouveau-portrait-lumiere']} alt="" loading="lazy"/><span>LA LUMIÈRE</span></div>
  <div className="story-side story-right" aria-hidden="true"><img src={NEW_PHOTOS['nouveau-robe-rouge']} alt="" loading="lazy"/><span>LE MOUVEMENT</span></div>
  <div className="stories-copy"><p className="eyebrow">LES GESTES PASSENT. LES SOUVENIRS RESTENT.</p><h2>Tout ce que<br/>vous avez <em>ressenti.</em></h2><a className="button light" href="#/souvenirs">Entrer dans les histoires <ArrowUpRight size={18}/></a></div>
  <div className="stories-foot"><span>UN INSTANT. MILLE FAÇONS DE S’EN SOUVENIR.</span><span>LE CARNET GOLDEN MOMENT <i/></span></div>
 </div></section>
}
