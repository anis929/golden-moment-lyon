import {useEffect,useState,useId} from 'react';
import {ArrowUpRight} from 'lucide-react';
import {NEW_PHOTOS} from './new-photos';

export function useScrollReveals(view:string){
 useEffect(()=>{
  const media=matchMedia('(prefers-reduced-motion: reduce)');
  const nodes=Array.from(document.querySelectorAll<HTMLElement>('.feeling-copy,.memory-heading,.memory,.section-top,.shooting-copy,.about-copy,.process-grid article,.values article,.review-card,.contact-banner h2'));
  const show=()=>nodes.forEach(n=>{n.classList.remove('reveal-ready');n.classList.add('is-revealed')});
  if(media.matches||!('IntersectionObserver' in window)){show();return}
  const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('is-revealed');observer.unobserve(e.target)}}),{threshold:.1,rootMargin:'0px 0px -25px 0px'});
  nodes.forEach((n,i)=>{n.classList.add('reveal-ready');n.style.setProperty('--reveal-delay',`${n.matches('.process-grid article,.memory')?(i%3)*90:0}ms`);observer.observe(n)});
  const onChange=()=>{if(media.matches){show();observer.disconnect()}};
  media.addEventListener('change',onChange);
  return()=>{observer.disconnect();media.removeEventListener('change',onChange)};
 },[view]);
}

const moments=[
 {name:'La joie',note:'Ce rire qu’on ne pouvait pas prévoir.',image:'nouveau-fontaine-joie',alt:'Un couple riant ensemble près d’une fontaine ensoleillée',caption:'Les éclats de rire. Sans les mettre en scène.',position:'50% 50%'},
 {name:'La tendresse',note:'Le calme, entre deux grands moments.',image:'nouveau-fontaine-tendresse',alt:'Un couple enlacé sur un banc, dans la lumière dorée du jardin',caption:'Les gestes discrets. Ceux qui disent tout.',position:'50% 50%'},
 {name:'Les détails',note:'La beauté que l’on garde tout près.',image:'nouveau-bouquet-dentelle',alt:'Un bouquet de roses blanches, une bague et une robe en dentelle',caption:'Une bague. Quelques fleurs. Votre histoire.',position:'50% 56%'},
];
export default function StoryNotebook(){
 const [active,setActive]=useState(0);const id=useId();
 function select(i:number,focus=false){setActive(i);if(focus)document.getElementById(id+'-tab-'+i)?.focus()}
 return <section className="story-notebook section" aria-labelledby={id+'-title'}>
  <div className="notebook-copy"><p className="eyebrow">DANS LE CARNET · UNE SÉANCE À DEUX</p><h2 id={id+'-title'}>Une histoire.<br/><em>Mille nuances.</em></h2><p className="notebook-intro">Un éclat de rire, un geste tendre, un détail précieux. La même histoire, racontée sous trois regards.</p>
   <div className="notebook-choices" role="tablist" aria-label="Explorer les regards de cette séance">{moments.map((m,i)=><button key={m.name} id={id+'-tab-'+i} role="tab" aria-selected={active===i} aria-controls={id+'-panel'} tabIndex={active===i?0:-1} onClick={()=>select(i)} onKeyDown={e=>{if(['ArrowRight','ArrowLeft','ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();select(e.key==='Home'?0:e.key==='End'?2:(active+(['ArrowRight','ArrowDown'].includes(e.key)?1:2))%3,true)}}}><span className="notebook-number">0{i+1}</span><span><strong>{m.name}</strong><small>{m.note}</small></span><ArrowUpRight size={17}/></button>)}</div>
  </div>
  <div className="notebook-page" id={id+'-panel'} role="tabpanel" aria-labelledby={id+'-tab-'+active}><div className="notebook-image">{moments.map((m,i)=><img key={m.image} className={active===i?'is-current':''} src={NEW_PHOTOS[m.image]} alt={active===i?m.alt:''} aria-hidden={active!==i} style={{objectPosition:m.position}} loading="lazy" decoding="async"/>)}<span className="notebook-index" aria-hidden="true">0{active+1}<i/>03</span></div><div className="notebook-caption"><p key={active}>{moments[active].caption}</p><a className="text-link" href="#/souvenirs?collection=a-deux">Découvrir cette séance <ArrowUpRight size={17}/></a></div></div>
 </section>
}
