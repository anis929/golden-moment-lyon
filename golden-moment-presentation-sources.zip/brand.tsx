import {ASSETS} from './assets';
import {useId} from 'react';
export default function BrandMark({className='',decorative=false}:{className?:string,decorative?:boolean}){
 const id=useId();
 return <svg className={'brand-mark '+className} viewBox="0 302 894 342" role={decorative?undefined:'img'} aria-label={decorative?undefined:'Golden Moment — Créatrice de contenu mariage'} aria-hidden={decorative||undefined} focusable="false"><defs><filter id={id} colorInterpolationFilters="sRGB"><feColorMatrix type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  -4 -4 -4 0 11.25"/></filter></defs><image href={ASSETS['logo.jpg']} width="894" height="894" x="0" y="0" filter={'url(#'+id+')'}/></svg>
}
