import {build} from 'vite';
import react from '@vitejs/plugin-react';
import fs from 'node:fs/promises';
await build({configFile:false,base:'./',publicDir:false,plugins:[react()],build:{outDir:'dist',emptyOutDir:true,cssCodeSplit:false,assetsInlineLimit:Infinity,rollupOptions:{output:{inlineDynamicImports:true}}}});
let html=await fs.readFile('dist/index.html','utf8');
for(const m of [...html.matchAll(/<script[^>]*src="([^"]+)"[^>]*><\/script>/g)]){const js=await fs.readFile('dist/'+m[1].replace(/^\.\//,''),'utf8');html=html.replace(m[0],()=>'<script type="module">'+js.replace(/<\/script/gi,'<\\/script')+'</script>')}
for(const m of [...html.matchAll(/<link[^>]*href="([^"]+\.css)"[^>]*>/g)]){const css=await fs.readFile('dist/'+m[1].replace(/^\.\//,''),'utf8');html=html.replace(m[0],()=>'<style>'+css+'</style>')}
await fs.writeFile('dist/index.html',html);console.log('Présentation autonome : '+(Buffer.byteLength(html)/1024/1024).toFixed(2)+' Mo');
