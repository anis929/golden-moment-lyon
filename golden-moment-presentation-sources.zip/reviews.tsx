import {useEffect,useRef,useState} from 'react';
import {ArrowLeft,ArrowRight,ArrowUpRight,X} from 'lucide-react';
import {reviews} from './reviews-data';

export default function Reviews({standalone=false}:{standalone?:boolean}){
 const [opened,setOpened]=useState<number|null>(null);
 const closeButton=useRef<HTMLButtonElement>(null),reader=useRef<HTMLDivElement>(null),previous=useRef<HTMLElement|null>(null);
 const isOpen=opened!==null;
 useEffect(()=>{
  if(!isOpen)return;
  previous.current=document.activeElement as HTMLElement;
  const savedOverflow=document.body.style.overflow;
  document.body.style.overflow='hidden';closeButton.current?.focus();
  const onKey=(e:KeyboardEvent)=>{
   if(e.key==='Escape')setOpened(null);
   if(e.key==='ArrowRight'){e.preventDefault();setOpened(x=>x===null?null:(x+1)%reviews.length)}
   if(e.key==='ArrowLeft'){e.preventDefault();setOpened(x=>x===null?null:(x+reviews.length-1)%reviews.length)}
   if(e.key==='Tab'){
    const nodes=Array.from(reader.current?.querySelectorAll<HTMLElement>('button,a[href],summary')||[]);
    const first=nodes[0],last=nodes[nodes.length-1];
    if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus()}
    else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus()}
   }
  };
  document.addEventListener('keydown',onKey);
  return()=>{document.removeEventListener('keydown',onKey);document.body.style.overflow=savedOverflow;previous.current?.focus()}
 },[isOpen]);
 useEffect(()=>{if(reader.current)reader.current.scrollTop=0},[opened]);
 const Title=standalone?'h1':'h2';
 const selected=opened===null?null:reviews[opened];
 return <section className={'reviews-section section '+(standalone?'reviews-page':'')} id="avis">
  <div className="section-top"><div><p className="eyebrow">LEURS MOTS, TOUT SIMPLEMENT</p><Title>Les images restent.<br/><em>Vos mots aussi.</em></Title></div><p>Les retours reçus après vos mariages,<br/>shootings et collaborations.</p></div>
  <div className="reviews-grid">{reviews.map((review,index)=><article className="review-card" key={review.id}>
   <button className="review-original" aria-label={'Ouvrir le message complet : '+review.label} onClick={()=>setOpened(index)}><img src={review.image} width={review.width} height={review.height} loading="lazy" alt={'Capture recadrée du message — '+review.label}/><span>LE MESSAGE ORIGINAL <ArrowUpRight size={13}/></span></button>
   <div className="review-copy"><p className="review-label"><span>{review.number}</span>{review.label}</p><blockquote>« {review.quote} »</blockquote><p className="review-context">{review.detail}</p><button className="text-link" onClick={()=>setOpened(index)}>Lire le message <ArrowUpRight size={16}/></button></div>
  </article>)}</div>
  {selected&&<div className="review-overlay" onClick={()=>setOpened(null)}><div className="review-reader" ref={reader} role="dialog" aria-modal="true" aria-labelledby="review-reader-title" onClick={e=>e.stopPropagation()}>
   <div className="review-reader-header"><div><span>MESSAGE {selected.number} / 04</span><h2 id="review-reader-title">{selected.label}</h2></div><button ref={closeButton} className="review-close" onClick={()=>setOpened(null)} aria-label="Fermer l’avis"><X size={20}/></button></div>
   <div className="review-reader-image"><img src={selected.image} width={selected.width} height={selected.height} alt={'Message original complet — '+selected.label}/></div>
   <div className="review-reader-footer"><button onClick={()=>setOpened(x=>x===null?null:(x+reviews.length-1)%reviews.length)}><ArrowLeft size={16}/> Avis précédent</button><span aria-live="polite">{selected.number} / 04</span><button onClick={()=>setOpened(x=>x===null?null:(x+1)%reviews.length)}>Avis suivant <ArrowRight size={16}/></button></div>
  </div></div>}
 </section>
}
