import React,{useEffect,useState} from 'react';
import {createRoot} from 'react-dom/client';
import Site from './site';
import './style.css';
const views:Record<string,string>={'/':'accueil','/a-propos':'apropos','/souvenirs':'souvenirs','/prestations':'prestations','/devis':'devis','/confidentialite':'confidentialite','/suivi':'suivi'};
function route(){return location.hash.startsWith('#/')?location.hash.slice(1):'/'}
function App(){const [path,setPath]=useState(route());useEffect(()=>{const fn=()=>{if(location.hash.startsWith('#/')){setPath(route());window.scrollTo({top:0,behavior:'instant'})}};window.addEventListener('hashchange',fn);return()=>window.removeEventListener('hashchange',fn)},[]);return <Site key={path} view={views[path.split('?')[0]]||'accueil'}/>}
createRoot(document.getElementById('root')!).render(<App/>);
