import {ASSETS} from './assets';
import {NEW_PHOTOS} from './new-photos';

import {useEffect,useRef} from 'react';
import {ArrowDown,ArrowUpRight} from 'lucide-react';
import BrandMark from './brand';
export default function CinemaIntro(){
 const ref=useRef<HTMLElement>(null);
 useEffect(()=>{
  const node=ref.current;if(!node)return;let frame=0;
  const reduce=window.matchMedia('(prefers-reduced-motion: reduce)');
  const update=()=>{frame=0;const r=node.getBoundingClientRect();const p=Math.max(0,Math.min(1,-r.top/(r.height-innerHeight)));const f=reduce.matches?1:p;
   node.style.setProperty('--progress',String(f));node.style.setProperty('--logo-opacity',String(Math.max(0,1-f*2.3)));node.style.setProperty('--film-opacity',String(Math.min(1,f*3.5)));node.style.setProperty('--film-inset',`${Math.max(0,37-f*66)}%`);node.style.setProperty('--film-round',`${Math.max(0,180-f*320)}px`);node.style.setProperty('--title-opacity',String(Math.max(0,Math.min(1,(f-.48)*4))));node.style.setProperty('--orbit-opacity',String(Math.max(0,1-f*2.5)));node.style.setProperty('--title-shift',`${Math.max(0,35-f*55)}px`);
   node.classList.toggle('film-visible',f>.5);document.documentElement.classList.toggle('cinema-active',f>.56&&r.bottom>innerHeight*.6);document.documentElement.classList.toggle('brand-revealed',f>.35);
  };
  const schedule=()=>{if(!frame)frame=requestAnimationFrame(update)};update();window.addEventListener('scroll',schedule,{passive:true});window.addEventListener('resize',schedule);reduce.addEventListener('change',schedule);
  return()=>{window.removeEventListener('scroll',schedule);window.removeEventListener('resize',schedule);reduce.removeEventListener('change',schedule);cancelAnimationFrame(frame);document.documentElement.classList.remove('cinema-active','brand-revealed')}
 },[]);
 return <section ref={ref} className="cinema-scroll" aria-label="L’univers Golden Moment"><div className="cinema-stage"><div className="cinema-film"><img src={ASSETS['hero.jpg']} alt="Un couple de mariés marchant main dans la main dans un jardin — Golden Moment" fetchPriority="high"/><div className="film-shade"/></div>
  <div className="opening-orbits" aria-hidden="true"><div className="orbit orbit-one"><img src={NEW_PHOTOS['nouveau-portrait-broderies']} alt=""/></div><div className="orbit orbit-two"><img src={NEW_PHOTOS['nouveau-couple-sortie']} alt=""/></div><div className="orbit orbit-three"><img src={NEW_PHOTOS['nouveau-couple-roses']} alt=""/></div><div className="orbit orbit-four"><img src={ASSETS['details.jpg']} alt=""/></div></div>
  <div className="opening-logo"><p className="eyebrow">DES INSTANTS VÉCUS. DES ÉMOTIONS GARDÉES.</p><BrandMark/><p className="opening-signature">Ce qui compte, <em>c’est ce qui reste.</em></p></div>
  <div className="cinema-title"><p className="eyebrow">MARIAGES · ÉVÉNEMENTS · LYON & ALENTOURS</p><h1>L’instant passe.<br/><em>L’émotion reste.</em></h1><div className="cinema-title-bottom"><p>Vous vivez. Je capture.<br/>Pour que rien ne s’oublie.</p><a className="button" href="#/devis">Confiez-moi votre histoire <ArrowUpRight size={18}/></a></div></div>
  <div className="cinema-bottom"><a href="#histoire" className="scroll-invitation"><span>DÉFILEZ POUR RESSENTIR</span><span className="scroll-circle"><ArrowDown size={19}/></span></a><div className="cinema-caption"><span>GOLDEN MOMENT — LE CARNET DES ÉMOTIONS</span><span>01 <i/> 04</span></div></div>
 </div></section>
}
