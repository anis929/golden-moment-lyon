export const options=['Vidéo récap','Livre d’or vidéo','Montage Reels','Photo argentique'];
export const services=[
 {name:'First Look',n:'01',duration:'3 h',hours:3,text:'Le premier regard. Les premières émotions. L’essentiel de votre histoire, saisi sur le vif.',image:'preparatifs',items:['Rendez-vous préalable de préparation','Photos & vidéos illimitées','Contenu brut, vivant & authentique','1 teaser','Livraison express en 24 à 72 h'],included:[] as string[]},
 {name:'Inoubliable',n:'02',duration:'6 h',hours:6,text:'Le temps de vivre, de rire, de s’émouvoir. Et de garder les plus beaux moments, tout près.',image:'hero',items:['Rendez-vous préalable de préparation','Photos illimitées en HD / 4K','1 vidéo récap des plus beaux moments','Livraison en 24 à 72 h'],included:['Vidéo récap']},
 {name:'Infinity',n:'03',duration:'10 h',hours:10,text:'Des premiers frissons aux derniers regards. Une présence prolongée pour une journée qui ne ressemble qu’à vous.',image:'ceremonie',items:['Rendez-vous préalable de préparation','Photos illimitées en HD / 4K','1 teaser','1 vidéo récap des plus beaux moments','Livraison rapide en 24 à 72 h'],included:['Vidéo récap']},
];
export const shootings=[{name:'Shooting couple',label:'Juste vous deux.',image:'voyage'},{name:'Shooting gender reveal',label:'Une si belle nouvelle.',image:'details'},{name:'Shooting demande en mariage',label:'Ce grand petit oui.',image:'bride'}];
export const serviceNames=[...services.map(x=>x.name),...shootings.map(x=>x.name),'Événement professionnel sur mesure'];
