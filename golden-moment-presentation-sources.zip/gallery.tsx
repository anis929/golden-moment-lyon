import {useState,useEffect,useRef} from 'react';
import {ArrowUpRight,ArrowRight,ArrowLeft,Play,Plus,X} from 'lucide-react';
import {ASSETS} from './assets';
import {NEW_PHOTOS} from './new-photos';
type Photo={image:string,title:string,category:string,reel?:string,position?:string};
const images:Photo[]=[
 {image:'nouveau-couple-sortie',title:'Le bonheur au grand jour',category:'Mariages'},
 {image:'nouveau-portrait-jardin',title:'L’or et la lumière',category:'Portraits & traditions'},
 {image:'nouveau-mariee-bouquet',title:'Les fleurs, avant le oui',category:'Mariages'},
 {image:'nouveau-robe-rouge',title:'Le rouge en mouvement',category:'Portraits & traditions'},
 {image:'nouveau-couple-voile',title:'Le monde, sous un voile',category:'Mariages'},
 {image:'nouveau-detail-henne',title:'Tout est dans les détails',category:'Mariages',position:'50% 57%'},
 {image:'nouveau-portrait-lumiere',title:'Une lumière dorée',category:'Portraits & traditions'},
 {image:'nouveau-couple-pavillon',title:'Un instant à deux',category:'Mariages'},
 {image:'nouveau-couple-escalier',title:'Le début de la suite',category:'Mariages',position:'50% 58%'},
 {image:'nouveau-portrait-broderies',title:'La beauté du geste',category:'Portraits & traditions'},
 {image:'nouveau-couple-roses',title:'Parmi les roses',category:'Mariages'},
 {image:'nouveau-couple-jardin',title:'Le temps de se retrouver',category:'Mariages',position:'50% 57%'},
 {image:'bride',title:'Une journée, mille émotions',category:'Mariages',reel:'De44KmiMXPV'},
 {image:'traditions',title:'La beauté des traditions',category:'Événements',reel:'DewhdCdN00S'},
 {image:'atelier',title:'Les coulisses de vos projets',category:'Professionnel',reel:'Dee1x4dtFzZ'},
 {image:'henne',title:'Les détails qui racontent tout',category:'Événements',reel:'DecMB3dq8TP'},
 {image:'hero',title:'Juste vous, juste l’instant',category:'Mariages'},
 {image:'preparatifs',title:'Avant le grand oui',category:'Mariages'},
 {image:'details',title:'Les petits bonheurs',category:'Mariages'},
 {image:'ceremonie',title:'Le début de votre histoire',category:'Mariages'},
];
function Img({photo}:{photo:Photo}){return <img src={NEW_PHOTOS[photo.image]||ASSETS[photo.image+'.jpg']} alt={photo.title} loading="lazy" decoding="async" style={{objectPosition:photo.position||'50% 40%'}}/>}
export default function Gallery({short=false}:{short?:boolean}){
 const [filter,setFilter]=useState('Tous'),[index,setIndex]=useState<number|null>(null),[consent,setConsent]=useState(false);
 const selected=index===null?null:images[index];
 const close=useRef<HTMLButtonElement>(null),previous=useRef<HTMLElement|null>(null);
 const visible=images.filter(x=>filter==='Tous'||x.category===filter).slice(0,short?4:images.length);
 const move=(by:number)=>{if(!selected)return;const pos=visible.indexOf(selected);const next=visible[(pos+by+visible.length)%visible.length];setIndex(images.indexOf(next));setConsent(false)};
 useEffect(()=>{if(index===null)return;previous.current=document.activeElement as HTMLElement;close.current?.focus();const overflow=document.body.style.overflow;document.body.style.overflow='hidden';return()=>{document.body.style.overflow=overflow;previous.current?.focus()}},[index===null]);
 useEffect(()=>{if(index===null)return;const fn=(e:KeyboardEvent)=>{if(e.key==='Escape')setIndex(null);if(e.key==='ArrowRight'){e.preventDefault();move(1)}if(e.key==='ArrowLeft'){e.preventDefault();move(-1)}if(e.key==='Tab'){const nodes=Array.from(document.querySelectorAll<HTMLElement>('.gallery-dialog button,.gallery-dialog a,.gallery-dialog iframe'));if(!nodes.length)return;const first=nodes[0],last=nodes[nodes.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}};document.addEventListener('keydown',fn);return()=>document.removeEventListener('keydown',fn)},[index,filter,short]);
 return <><div className="section-top"><div><p className="eyebrow">LE CARNET DES SOUVENIRS</p><h2>Des instants vrais.<br/><em>Des émotions intactes.</em></h2></div>{short?<a className="text-link" href="#/souvenirs">Explorer le portfolio <ArrowUpRight size={17}/></a>:<p>Mariages, portraits, gestes et traditions.<br/>Des histoires à découvrir, image après image.</p>}</div>{!short&&<div className="filters" aria-label="Filtrer le portfolio">{['Tous','Mariages','Portraits & traditions','Événements','Professionnel'].map(x=><button key={x} className={filter===x?'active':''} onClick={()=>setFilter(x)} aria-pressed={filter===x}>{x}</button>)}</div>}
 <div className={'gallery '+(short?'gallery-short':'')} key={filter}>{visible.map((x,i)=><button className="gallery-item" key={x.image} style={{'--gallery-order':Math.min(i,7)} as React.CSSProperties} onClick={()=>{setIndex(images.indexOf(x));setConsent(false)}}><div className="gallery-photo"><Img photo={x}/><span className="play">{x.reel?<Play size={18} fill="currentColor"/>:<Plus size={22}/>}</span><span className="photo-tag">{x.reel?'VOIR LE REEL':'VOIR LA PHOTO'}</span></div><span className="gallery-caption"><span>{x.title}</span><ArrowUpRight size={17}/></span><small>{x.category}</small></button>)}</div>
 {selected&&<div className="overlay" onClick={()=>setIndex(null)}><div className={(selected.reel?'modal':'photo-viewer')+' gallery-dialog'} role="dialog" aria-modal="true" aria-label={selected.title} onClick={e=>e.stopPropagation()}><button ref={close} className="close" onClick={()=>setIndex(null)} aria-label="Fermer la photo"><X/></button>{selected.reel?(consent?<iframe title={selected.title} src={`https://www.instagram.com/reel/${selected.reel}/embed/`} allow="autoplay; encrypted-media; fullscreen" referrerPolicy="strict-origin-when-cross-origin"/>:<Img photo={selected}/>):<div className="viewer-image"><Img photo={selected}/></div>}<div className="modal-copy"><p className="eyebrow">{selected.category}</p><h3>{selected.title}</h3>{selected.reel&&<><p>La lecture charge un contenu Instagram. Meta peut utiliser des cookies et recevoir votre adresse IP.</p><button className="button" onClick={()=>setConsent(true)}>Charger le Reel <Play size={16}/></button><a href={`https://www.instagram.com/reel/${selected.reel}/`} target="_blank" rel="noopener noreferrer" className="text-link">Ouvrir sur Instagram <ArrowUpRight size={16}/></a></>}<div className="viewer-navigation"><button onClick={()=>move(-1)} aria-label="Photo précédente"><ArrowLeft size={17}/></button><span>{String(visible.indexOf(selected)+1).padStart(2,'0')} / {String(visible.length).padStart(2,'0')}</span><button onClick={()=>move(1)} aria-label="Photo suivante"><ArrowRight size={17}/></button></div></div></div></div>}</>
}
